Let your code generate logs automatically

- [x] 0.0.1 : 2020/8/17 原始版本

- [x] 0.0.2 : 2020/8/17 修正debug.log路径

- [x] 0.0.3 : 2020/8/17 修正debug.log路径

- [x] 0.0.5 : 2020/8/18 将函数中的print输出记录到日志中